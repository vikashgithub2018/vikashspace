# DefaultApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getGet**](DefaultApi.md#getGet) | **GET** /get | 


<a name="getGet"></a>
# **getGet**
> getGet(size, format)



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.RandomCatImage.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String size = "size_example"; // String | 
String format = "format_example"; // String | 
try {
    apiInstance.getGet(size, format);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **size** | **String**|  | [optional]
 **format** | **String**|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

